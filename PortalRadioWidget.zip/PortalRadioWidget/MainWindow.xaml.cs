using System;
using System.IO;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging; // BitmapImage için gerekli
using NAudio.Wave;

namespace PortalRadioWidget
{
    public partial class MainWindow : Window
    {
        private bool isRadioOn = false;
        private WaveOutEvent? audioPlayer;
        private LoopStream? loopStream;
        private BitmapImage? radioImageSource; // Tek resim için kaynak

        public MainWindow()
        {
            InitializeComponent();

            // Pencereyi sağ alta konumlandır
            var workArea = SystemParameters.WorkArea;
            this.Left = workArea.Right - this.Width;
            this.Top = workArea.Bottom - this.Height;

            LoadRadioImage("radio.png"); // Tek resmi yükle
            SetupAudio();
            UpdateRadioState(); // Başlangıçta sesi kapalı tut
        }

        private void LoadRadioImage(string imageName)
        {
            try
            {
                string imagePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Resources", imageName);
                if (!File.Exists(imagePath))
                {
                    MessageBox.Show($"Resim dosyası bulunamadı!\nBeklenen konum: {imagePath}\nLütfen '{imageName}' dosyasını Resources klasörüne ekleyin.", "Hata", MessageBoxButton.OK, MessageBoxImage.Error);
                    // Uygulamayı kapatmak yerine sadece resmi boş bırakabiliriz
                    radioImageSource = null; 
                    RadioImage.Source = null;
                    return;
                }

                radioImageSource = new BitmapImage(new Uri(imagePath));
                RadioImage.Source = radioImageSource;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Resim yüklenirken bir hata oluştu: {ex.Message}", "Resim Yükleme Hatası", MessageBoxButton.OK, MessageBoxImage.Warning);
                radioImageSource = null;
                RadioImage.Source = null;
            }
        }
        
        private void Window_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ButtonState == MouseButtonState.Pressed) DragMove();
        }

        private void ToggleButton_Click(object sender, RoutedEventArgs e)
        {
            isRadioOn = !isRadioOn;
            UpdateRadioState();
        }

        private void SetupAudio()
        {
            try
            {
                string audioPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Resources", "radio_loop.mp3");
                if (!File.Exists(audioPath))
                {
                    ToggleButton.IsEnabled = false;
                    ToggleButton.Content = "NO SOUND FILE";
                    return;
                }
                var reader = new Mp3FileReader(audioPath);
                loopStream = new LoopStream(reader);
                audioPlayer = new WaveOutEvent();
                audioPlayer.Init(loopStream);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ses dosyası yüklenirken bir hata oluştu: {ex.Message}", "Ses Hatası", MessageBoxButton.OK, MessageBoxImage.Warning);
                ToggleButton.IsEnabled = false;
                ToggleButton.Content = "AUDIO ERROR";
            }
        }

        private void UpdateRadioState()
        {
            if (isRadioOn)
            {
                audioPlayer?.Play();
                ToggleButton.Content = "TURN OFF";
                ToggleButton.Background = new SolidColorBrush(Colors.DarkRed);
            }
            else
            {
                audioPlayer?.Stop();
                if (loopStream != null) loopStream.Position = 0;
                ToggleButton.Content = "TURN ON";
                ToggleButton.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF333333"));
            }
        }
    }

    public class LoopStream : WaveStream
    {
        private readonly WaveStream sourceStream;
        public LoopStream(WaveStream sourceStream)
        {
            this.sourceStream = sourceStream;
            this.EnableLooping = true;
        }
        public bool EnableLooping { get; set; }
        public override WaveFormat WaveFormat => sourceStream.WaveFormat;
        public override long Length => sourceStream.Length;
        public override long Position
        {
            get => sourceStream.Position;
            set => sourceStream.Position = value;
        }
        public override int Read(byte[] buffer, int offset, int count)
        {
            int totalBytesRead = 0;
            while (totalBytesRead < count)
            {
                int bytesRead = sourceStream.Read(buffer, offset + totalBytesRead, count - totalBytesRead);
                if (bytesRead == 0)
                {
                    if (sourceStream.Position == 0 || !EnableLooping) break;
                    sourceStream.Position = 0;
                }
                totalBytesRead += bytesRead;
            }
            return totalBytesRead;
        }
    }
}
